
Nama anggota kelompok :
1. Amanat  					(2014150090)


----------------------------------------------------------------
- Instal Laravel: `composer install --prefer-dist`
- Migrasikan database: `php artisan migrate`
- Ketikan Perintah: `php artisan db: seed`
- Lihat aplikasi di browser.
